import { NextResponse } from 'next/server'
export const dynamic = 'force-dynamic'
export async function GET() {
  // Minimal health info — in a real app we'd read counters from a store
  return NextResponse.json({ ok: true, ts: new Date().toISOString(), service: 'automation-engine-thin-slice' })
}
