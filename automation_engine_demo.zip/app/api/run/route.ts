import { NextResponse } from 'next/server'

type Lead = {
  name: string
  email: string
  message: string
}

// naive validation to avoid adding deps
function validate(body: any): { ok: boolean; data?: Lead; error?: string } {
  if (!body || typeof body !== 'object') return { ok: false, error: 'Invalid JSON body' }
  const { name, email, message } = body
  if (!name || !email || !message) return { ok: false, error: 'name, email, message are required' }
  if (String(email).indexOf('@') === -1) return { ok: false, error: 'Invalid email' }
  return { ok: true, data: { name: String(name), email: String(email), message: String(message) } }
}

// trivial classifier (keywords). If OPENAI_API_KEY is set, we can upgrade later.
function classify(msg: string): 'training' | 'consulting' | 'build' {
  const m = msg.toLowerCase()
  if (/(workshop|training|teach|course)/.test(m)) return 'training'
  if (/(consult|strategy|advice|audit)/.test(m)) return 'consulting'
  return 'build'
}

function draftReply(kind: ReturnType<typeof classify>, lead: Lead) {
  const base = {
    subject: '',
    body: ''
  }
  if (kind === 'training') {
    base.subject = `Training request — next steps`
    base.body = `Hi ${lead.name},\n\nThanks for reaching out about AI training. We can do a 30–45 min discovery to tailor a session for your team. If you’re up for it, pick a time here: <YOUR_CALENDLY_LINK>.\n\nWe’ll come prepared with a thin-slice curriculum and hands-on exercises.\n\nCheers,\nYour Team`
  } else if (kind === 'consulting') {
    base.subject = `Quick consult to map your automation ROI`
    base.body = `Hi ${lead.name},\n\nAppreciate your interest. We suggest a short consult focused on 1–2 workflows to unlock fast ROI (≤14 days). Book here: <YOUR_CALENDLY_LINK>.\n\nWe’ll map the process, target metrics, and a thin-slice pilot.\n\nBest,\nYour Team`
  } else {
    base.subject = `We can prototype a thin-slice build in 7–14 days`
    base.body = `Hi ${lead.name},\n\nThanks for the note. We can build a small, end-to-end automation (lead → action → metric) as a pilot. If that sounds good, schedule here: <YOUR_CALENDLY_LINK>.\n\nWe’ll send a 2‑page plan and a live demo link after the call.\n\nBest,\nYour Team`
  }
  return base
}

// optional OpenAI refinement (disabled by default — no outbound in sandbox)
async function refineWithOpenAI(draft: {subject: string; body: string}, intent: string, lead: Lead) {
  if (!process.env.OPENAI_API_KEY) return draft
  try {
    const OpenAI = (await import('openai')).default
    const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY })
    const system = `You refine short email drafts. Keep them under 120 words, plain language, friendly and clear. Preserve any scheduling links as-is.`
    const user = `Intent: ${intent}\nLead: ${JSON.stringify(lead)}\nDraft: ${JSON.stringify(draft)}`
    const out = await client.chat.completions.create({
      model: 'gpt-4o-mini',
      messages: [{ role: 'system', content: system }, { role: 'user', content: user }],
      temperature: 0.3
    })
    const content = out.choices?.[0]?.message?.content || ''
    if (content && content.includes('\n')) {
      // expect "Subject: ...\nBody: ..."
      const subj = content.match(/Subject:\s*(.*)/i)?.[1]?.trim()
      const body = content.split(/Body:\s*/i)?.[1]?.trim()
      if (subj && body) return { subject: subj, body }
    }
    return draft
  } catch (e) {
    return draft
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json().catch(() => ({}))
    const v = validate(body)
    if (!v.ok) return NextResponse.json({ error: v.error }, { status: 400 })
    const intent = classify(v.data!.message)
    const draft = draftReply(intent, v.data!)
    const refined = await refineWithOpenAI(draft, intent, v.data!)
    // Demo mode: write to tmp-like in-memory object — in serverless this is ephemeral.
    const id = Math.random().toString(36).slice(2, 8)
    return NextResponse.json({ id, intent, draft: refined, received: v.data }, { status: 200 })
  } catch (e:any) {
    return NextResponse.json({ error: 'Unexpected error', detail: String(e?.message || e) }, { status: 500 })
  }
}
