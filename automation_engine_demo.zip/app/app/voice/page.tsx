export const dynamic = "force-static";
export default function VoiceDemoPage() {
  return (
    <div style={{padding: "2rem"}}>
      <h1 style={{fontSize: "1.75rem", marginBottom: "1rem"}}>Voice Demo</h1>
      <p>Open the standalone demo here: <a href="/voice-demo/index.html" style={{color:"#e63946"}}>voice-demo / index.html</a>.</p>
      <p>If you imported the setup page, start at <a href="/voice-demo/setup.html" style={{color:"#e63946"}}>voice-demo / setup.html</a>.</p>
      <p>This demo calls <code>/api/run</code> and <code>/api/healthz</code> on the same host.</p>
    </div>
  );
}
