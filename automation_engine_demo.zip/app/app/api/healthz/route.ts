// Simple in-memory counters (ephemeral across deploys)
let counters = { requests: 0, drafts: 0, avgLatencyMs: 0 };

export async function GET() {
  counters.requests += 1;
  return new Response(JSON.stringify({ ok: true, ...counters, ts: new Date().toISOString() }), {
    headers: { "content-type": "application/json" },
  });
}

// Helper for other routes to update counters
export function _bumpDraft(latencyMs: number) {
  counters.drafts += 1;
  // naive moving average
  counters.avgLatencyMs = Math.round((counters.avgLatencyMs * (counters.drafts - 1) + latencyMs) / counters.drafts);
}
