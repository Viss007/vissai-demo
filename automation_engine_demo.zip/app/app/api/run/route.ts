import { NextRequest } from "next/server";
import { _bumpDraft } from "../healthz/route";

type RunBody = {
  name?: string;
  phone?: string;
  reason?: string;
  action?: "bookings" | "faq" | "support";
  lang?: "en" | "lt";
};

function triage(body: RunBody) {
  const text = (body.reason || "").toLowerCase();
  if (text.includes("book") || text.includes("rezerv")) return "booking";
  if (text.includes("question") || text.includes("klaus")) return "faq";
  return body.action || "support";
}

function replyDraft(body: RunBody, intent: string) {
  const name = body.name || "there";
  const lang = body.lang || "en";
  if (lang === "lt") {
    if (intent === "booking") {
      return {
        email: `Tema: Rezervacija\n\nSveiki, ${name}! Gavome jūsų užklausą dėl rezervacijos. Kada jums patogiausia data ir laikas?`,
        sms: `Sveiki, ${name}! kada norėtumėte rezervuoti laiką?`,
      };
    } else if (intent === "faq") {
      return {
        email: `Tema: Klausimas\n\nSveiki, ${name}! Ačiū už klausimą. Gal galite patikslinti detales, kad greičiau atsakytume?`,
        sms: `Sveiki! Gavome jūsų klausimą — galite patikslinti?`,
      };
    } else {
      return {
        email: `Tema: Pagalba\n\nSveiki, ${name}! Ačiū, kad susisiekėte. Trumpai aprašykite problemą — atsakysime kuo greičiau.`,
        sms: `Sveiki! Kaip galime padėti?`,
      };
    }
  }
  // English defaults
  if (intent === "booking") {
    return {
      email: `Subject: Booking\n\nHi ${name}, thanks for reaching out about a booking. What date/time works for you?`,
      sms: `Hi ${name}! What date/time works for your booking?`,
    };
  } else if (intent === "faq") {
    return {
      email: `Subject: Question\n\nHi ${name}, thanks for your question. Could you share a bit more detail so we can answer quickly?`,
      sms: `Hi! We got your question — any extra details?`,
    };
  } else {
    return {
      email: `Subject: Support\n\nHi ${name}, thanks for contacting us. Briefly describe the issue and we'll help ASAP.`,
      sms: `Hi! How can we help today?`,
    };
  }
}

export async function POST(req: NextRequest) {
  const t0 = Date.now();
  const body = (await req.json()) as RunBody;
  const intent = triage(body);
  const drafts = replyDraft(body, intent);
  const payload = {
    id: crypto.randomUUID(),
    intent,
    drafts,
    received: body,
  };
  const latency = Date.now() - t0;
  _bumpDraft(latency);
  return new Response(JSON.stringify(payload), { headers: { "content-type": "application/json" } });
}
